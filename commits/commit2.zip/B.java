class B extends D {
  public B() {
    z38 = 4;
    z15 = 2;
    z3 = 4L;
    z21 = 3L;
  }
  public void z25() {
    System.out.println("метод z25 в классе B");
    System.out.println(z6 + 5);
  }
  public void z8() {
    System.out.println("метод z8 в классе B");
    System.out.println(--z6);
  }
  public void z28() {
    System.out.println("метод z28 в классе B");
    System.out.println(z7);
  }
  public void z5() {
    System.out.println("метод z5 в классе B");
    System.out.println(z36);
  }
  public static void z37() {
    System.out.println("метод z37 в классе B");
    System.out.println(--z29);
  }
  public static void z20() {
    System.out.println("метод z20 в классе B");
    System.out.println(z13);
  }
  public static void z32() {
    System.out.println("метод z32 в классе B");
    System.out.println((z13 - 4));
  }
  public static void z10() {
    System.out.println("метод z10 в классе B");
    System.out.println(z13);
  }
  public void z9(D r) {
    r.z25();
  }
  public void z9(B r) {
    r.z8();
  }
}
