class D {
  int z36;
  int z38;
  int z15;
  int z7;
  int z6;
  long z3;
  long z21;
  long z30;
  int[] z31 = {3, 0, -1, 2, 3};
  int[] z23 = {2, 2, 3, 2};
  int[] z39 = {2, 0, 3, -3, -3};
  static int z29;
  static int z13;
  static int z26;
  static int z40;
  static int z24;
  public D() {
    z36 = 4;
    z38 = 3;
    z15 = 2;
    z7 = 4;
    z6 = 2;
    z3 = 6L;
    z21 = 2L;
    z30 = 9L;
  }
  public void z4() {
    System.out.println("метод z4 в классе D");
    System.out.println(z23[1]);
  }
  public void z2() {
    System.out.println("метод z2 в классе D");
    System.out.println(z36);
  }
  public void z25() {
    System.out.println("метод z25 в классе D");
    System.out.println(++z38);
  }
  public void z8() {
    System.out.println("метод z8 в классе D");
    System.out.println(++z26);
  }
  public void z28() {
    System.out.println("метод z28 в классе D");
    System.out.println(z36 - 2);
  }
  public void z5() {
    System.out.println("метод z5 в классе D");
    System.out.println(z7 >> 2);
  }
  public static void z37() {
    System.out.println("метод z37 в классе D");
    System.out.println(z40);
  }
  public static void z20() {
    System.out.println("метод z20 в классе D");
    System.out.println((z40 - 4));
  }
  public static void z32() {
    System.out.println("метод z32 в классе D");
    System.out.println(z24);
  }
  public static void z10() {
    System.out.println("метод z10 в классе D");
    System.out.println((z24 + 2));
  }
  public void z9(D r) {
    r.z4();
  }
  public void z9(B r) {
    r.z2();
  }
}
