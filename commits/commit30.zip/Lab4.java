// var. 360811
public class Lab4 {
  public static void main(String[] args) {
  D a = new D();
  D b = new B();
  B c = new B();
  b.z4();
  a.z2();
  a.z25();
  a.z8();
  c.z28();
  a.z5();
  c.z37();
  a.z20();
  c.z32();
  b.z10();
  b.z9(a);
  c.z9(b);
  b.z9(c);
  }
}
previous : 24
previous : 29
